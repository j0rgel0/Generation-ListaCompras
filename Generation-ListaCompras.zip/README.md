# ListaCompras
Se muestra una página que permite crear una lista de compras de forma dinámica usando HTML y Javascript
